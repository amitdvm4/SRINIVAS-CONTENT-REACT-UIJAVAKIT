import "./Header.css";
import React from "react";

function template() {
  return (
    <div className="header">
      My react web application
    </div>
  );
};

export default template;
