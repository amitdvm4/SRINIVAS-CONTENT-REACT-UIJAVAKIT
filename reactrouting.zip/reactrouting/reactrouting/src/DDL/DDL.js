import React    from "react";
import template from "./DDL.jsx";

class DDL extends React.Component {
  render() {
    return template.call(this);
  }
}

export default DDL;
