import DDL from "./DDL";
export default DDL;
