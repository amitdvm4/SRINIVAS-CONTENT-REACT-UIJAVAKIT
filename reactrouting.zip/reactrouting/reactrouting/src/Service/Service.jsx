import "./Service.css";
import React from "react";

function template() {
  return (
    <div className="service">
      <h1>Service</h1>
    </div>
  );
};

export default template;
