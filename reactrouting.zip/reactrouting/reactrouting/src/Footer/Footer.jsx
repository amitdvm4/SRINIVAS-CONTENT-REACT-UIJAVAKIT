import "./Footer.css";
import React from "react";

function template() {
  return (
    <div className="fs footer ">
     &copy; rignts belongs to me
    </div>
  );
};

export default template;
