Application Running Steps:

1. Go to package.json file folder.

2. Open command propmt and run 'npm install' commad

3. Run 'npm start' command to run application.