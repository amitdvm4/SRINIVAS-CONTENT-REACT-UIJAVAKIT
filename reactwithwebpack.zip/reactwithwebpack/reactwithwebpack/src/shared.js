export const userData={
    'name':'sachin',
    'age':40,
    'location':'mumbai'
}