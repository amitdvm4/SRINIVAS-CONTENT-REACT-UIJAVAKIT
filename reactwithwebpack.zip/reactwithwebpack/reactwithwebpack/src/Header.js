import React from 'react';

class Home extends React.Component{
    
    render(){
        return <div className="header">My REact Website</div>
    }
}

export default Home;