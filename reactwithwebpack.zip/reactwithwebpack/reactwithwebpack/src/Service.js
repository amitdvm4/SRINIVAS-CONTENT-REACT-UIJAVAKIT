import React from 'react';

class Service extends React.Component{
    render(){
        return <div>I am Service page</div>
    }
}

export default Service;