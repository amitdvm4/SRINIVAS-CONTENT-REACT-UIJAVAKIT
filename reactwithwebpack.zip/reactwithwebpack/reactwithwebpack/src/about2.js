import React from 'react';
import {UserContext} from './context'
class About2 extends React.Component{
    constructor(context){
        super();
        debugger;
    }

    render(){
        debugger;
        return <div>am about 2</div>
    }
}

About2.contextType =UserContext;



export default About2;