import React from 'react';

class Footer extends React.Component{
    render(){
        return <div className="footer">&copy; rights belongs to me</div>
    }
}

export default Footer;