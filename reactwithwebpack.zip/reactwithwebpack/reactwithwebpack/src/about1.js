import React from 'react';
import About2 from './about2';
const About1 =(d)=>{
    debugger;
    return <div>am about1 page: <About2 /></div>
}

export default About1;