import React from 'react';

class Contact extends React.Component{
    render(){
        return <div>I am Contact page</div>
    }
}

export default Contact;