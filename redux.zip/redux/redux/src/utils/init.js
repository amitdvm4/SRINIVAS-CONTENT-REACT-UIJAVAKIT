export const initValues={
    'name':'',
    'loc':''
}