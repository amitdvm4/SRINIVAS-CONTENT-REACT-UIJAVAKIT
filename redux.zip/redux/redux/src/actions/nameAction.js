const getNameAction=(data,d)=>{
    debugger;
     d({
        'type':'NAME',
        'payload':data
     });
}

export default getNameAction;