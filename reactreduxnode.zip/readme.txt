Application Running Steps:

Client(React):

1. Go to package.json file folder.

2. Open command propmt and run 'npm install' commad.

3. Run 'npm start' command to run application.

Server(Node):

1. Go to package.json file folder.

2. Open command propmt and run 'npm install' commad.

3. Run node app.js command to run application.