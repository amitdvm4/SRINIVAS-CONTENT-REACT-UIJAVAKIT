import Posts from "./Posts";
export default Posts;
