export const initVal={
    'posts':[],
    'photos':[]
}