import DispPosts from "./DispPosts";
export default DispPosts;
