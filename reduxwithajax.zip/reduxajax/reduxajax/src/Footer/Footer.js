import React    from "react";
import template from "./Footer.jsx";

class Footer extends React.Component {
  render() {
    return template.call(this);
  }
}

export default Footer;
